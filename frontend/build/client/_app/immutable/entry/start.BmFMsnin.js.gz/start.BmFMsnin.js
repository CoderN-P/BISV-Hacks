import{l as o,a as r}from"../chunks/6d_m6pp3.js";export{o as load_css,r as start};
